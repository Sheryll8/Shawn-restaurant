-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2021 at 05:25 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cookerydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `ordertable`
--

CREATE TABLE `ordertable` (
  `PRODUCT` text NOT NULL,
  `ORDER_NO` int(11) NOT NULL,
  `COST` int(11) NOT NULL,
  `CLIENT` text NOT NULL,
  `STATUS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordertable`
--

INSERT INTO `ordertable` (`PRODUCT`, `ORDER_NO`, `COST`, `CLIENT`, `STATUS`) VALUES
('Juice', 19331, 300, 'Sharon', 'Pending'),
('Juice', 94864, 300, 'Sharon', 'Pending'),
('', 90908, 0, '', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `producttable`
--

CREATE TABLE `producttable` (
  `ID` int(11) NOT NULL,
  `FOOD_PRODUCT` text NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `PRODUCT_PRICE` int(11) NOT NULL,
  `PRODUCT_TYPE` varchar(300) NOT NULL,
  `PRODUCT_IMAGE` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `producttable`
--

INSERT INTO `producttable` (`ID`, `FOOD_PRODUCT`, `QUANTITY`, `PRODUCT_PRICE`, `PRODUCT_TYPE`, `PRODUCT_IMAGE`) VALUES
(1, 'Tea', 15, 25, 'Breakfast', 'cookery/pics/tea.jpg'),
(2, 'Omelette', 30, 50, 'Breakfast', 'cookery/pics/omelette.jpg'),
(3, 'Beef', 26, 100, 'Lunch', 'cookery/pics/beef.jpg'),
(4, 'FISH', 10, 250, 'Dinner', 'cookery/pics/fish.jpg'),
(5, 'Cocktail', 16, 450, 'Beverages', 'cookery/pics/Cocktail.jpg'),
(7, 'Juice', 8, 150, 'Beverage', 'cookery/pics/juice.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `waitertable`
--

CREATE TABLE `waitertable` (
  `NAME` text NOT NULL,
  `EMPLOYER_NO` int(11) NOT NULL,
  `ZONE` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `waitertable`
--

INSERT INTO `waitertable` (`NAME`, `EMPLOYER_NO`, `ZONE`) VALUES
('SHARON', 711, 'NAIROBI'),
('STEPHANY', 712, 'KERICHO'),
('DANIEL', 713, 'KISUMU'),
('SHERYL', 717, 'MOMBASA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `producttable`
--
ALTER TABLE `producttable`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `producttable`
--
ALTER TABLE `producttable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
